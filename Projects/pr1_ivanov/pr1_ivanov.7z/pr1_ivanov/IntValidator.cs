﻿
namespace pr1_ivanov.Validators
{
    class IntValidator
    {
        static public bool Validate(int Value)
        {
            return Value > 0;
        }
    }
}
