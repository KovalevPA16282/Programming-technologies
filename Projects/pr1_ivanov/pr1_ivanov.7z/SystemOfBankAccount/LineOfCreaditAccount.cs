﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SystemOfBankAccount.Base;

namespace SystemOfBankAccount
{
    class LineOfCreaditAccount : BankAccount
    {

        public LineOfCreaditAccount(string owner, decimal intitialBalance)
            : base(owner, intitialBalance)
        {
        }

        public override void PerformMonthEndTransactions()
        {
            if (Balance < 0)
            {
                MakeWithdrawal(-Balance * 0.07m, DateTime.Now, "charge monthly interest");
            }
        }
    }
}
