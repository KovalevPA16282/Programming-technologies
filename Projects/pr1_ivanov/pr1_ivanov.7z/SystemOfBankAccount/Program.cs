﻿using System;

namespace SystemOfBankAccount
{
    class Program
    {          

        static void Main(string[] args)
        {

            var account1 = new InterestEarmingAccount("Qwerty1", 1000);
            Console.WriteLine($"Account {account1.Number.Value} "+
                                $"was created for {account1.Owner} " +
                                $"with {account1.Balance} initialBalance" );

            var account2 = new LineOfCreaditAccount("Qwerty2", 2000);
            Console.WriteLine($"Account {account2.Number.Value} " +
                                $"was created for {account2.Owner} " +
                                $"with {account2.Balance} initialBalance");
            // m - обознача
            account1.MakeDeposit(100m, DateTime.Now, "GOIDA!!!!!");
            account1.MakeDeposit(777777m, DateTime.Now, "GOIDA!!!!!");
            account1.MakeWithdrawal(500m, DateTime.Now, "GOIDA!!!!!");

            Console.WriteLine($"Account {account1.Number.Value} " +
                                $"was created for {account1.Owner} " +
                                $"with {account1.Balance} initialBalance");

            Console.WriteLine(account1.GetAccountHistory());
            
            try
            {
                account1.MakeWithdrawal(2000m, DateTime.Now, "GOIDA!!!!!");
            }
            catch (ArgumentOutOfRangeException e) // самый дальний по ветви наследования // 
            {
                Console.WriteLine(e.Message, e.ParamName);
            }
            catch (InvalidOperationException e) 
            {
                Console.WriteLine(e.Message,e.ToString());
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message, e.ToString());
            }

            


        }
    }
}