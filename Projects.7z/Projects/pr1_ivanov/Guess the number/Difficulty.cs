﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Guess_the_number
{
    // Перечисление сложностей
    // enum — это тип данных, который задает набор (перечисление) именованных значений
    public enum Difficulty
    {
        Easy = 10,
        Medium = 9,
        Hard = 8
    }
}
